package com.rich.test.gsrestclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsrestclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsrestclientApplication.class, args);
	}

}
