package com.rich.test.gsrestclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsrestclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
